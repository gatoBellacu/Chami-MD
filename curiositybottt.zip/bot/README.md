<h1 align="center">♻️ NK-BOT-MD ♻️</h1>
<br>
<div align="center">

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=00CB22&width=435&lines=Simple+WhatsApp+Bot+Multidevice+nwn;Gracias+por+usar+este+bot+my+king+%3A3;%5B+How+sexy+are+you+7w7r+%5D_)](https://git.io/typing-svg)
<img src="https://c.tenor.com/D2H0hPltOdYAAAAM/golden-boy-fake-keyboard-programing-coding-paper-book.gif" width="400" height="230"/>
</div>
<br>
<p align="center">
<a href="https://tinyurl.com/Onichan7w7r"><img title="WhatsApp-Bot-MD" src="https://img.shields.io/badge/-WHATSAPP--BOT--MD-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://tinyurl.com/2p9kb7yd"><img title="Autor" src="https://img.shields.io/badge/Autor-Matt_M-orange?style=for-the-badge&logo=github"></a>
</p>
</details>
</p>

# 📖 Características del bot 
|  Funciones y comandos  |                                           Sip |
| :---------------------------------------------: | :-----------: |
| Crea stickers|✔️|
| Bienvenida automática|✔️|
| Anti-Link|✔️|
| Anti-Fakes|✔️|
| Jadibot-vBeta|✔️|
| Anti-Estranjeros|✔️|
| Anti-Spam(Command flood)|✔️|
| Anti-Llamadas|✔️|
| Anti-Privados|✔️|
| Modo Publico/Privado|✔️|
| Herramientas de edición|✔️|
| Creador de logos|✔️|
| Anime|✔️|
| Juegos|✔️|
| Descarga de música/videos|✔️|
| Chat-Bot|✔️|
| Botones clásicos|✔️|
| Random commands|✔️|
| NSFW|🔞|
| Más funciones en adelante|♻️|

# 🪀 Instalación en varias plataformas...

# 📲Termux
Para nuevos desde cero en termux.apk:
```bash
> termux-setup-storage
(Dan permiso a su almacenamiento)
> termux-change-repo
(Seleccionan todas las opciones que les aparescan en la primera ventana || En la segunda ventana seleccionan la opcion que contenga las palabras 'termux.mentality.rip' )
> apt update -y && apt upgrade -y
> pkg install git
> pkg install nodejs
> pkg install libwebp -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> pkg install yarn

```
## Despues de tener todos los packs instalados en termux solo usen estos comandos para comenzar
```bash
> git clone [URL_DEL_REPOSITORIO_ACTUAL] 
> cd NK-BOT-MD
> yarn
> npm start

Para detener al bot en termux:
> Ctrl+c
```

# 🔥 Ejecutar el bot 24/7 
- Es aconsejable que crees una carpeta llamada "./sesiones/", luego subas el archivo de "creds.json" ya activado, para ya no tener que escanear otro código QR x'd

## Desplegable en Railway & Heroku
- Railway => https://railway.app/new/template?template=URL_del_repositorio_actual

- Heroku => https://heroku.com/deploy?template=URL_del_repositorio_actual

# ⚡ Necesitas ayuda?, Aquí tienes mi WhatsApp :3

<a href="https://wa.me/51995386439"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

# 🗿 Agradecido con el de arriba y a estos cracks :3

* <a href="https://github.com/adiwajshing/Baileys"><img alt="GitHub" src="https://img.shields.io/badge/adiwajshing/Baileys%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">
* <a href="https://github.com/BochilGaming"><img alt="GitHub" src="https://img.shields.io/badge/BochilGaming%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">
</p>
