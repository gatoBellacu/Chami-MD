#!/usr/bin/bash
rm -r sesiones
sleep 2.0
